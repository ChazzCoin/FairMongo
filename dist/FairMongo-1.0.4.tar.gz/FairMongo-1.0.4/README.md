It's coming. Shut up.

Version 1.0.0 -> We are Live!

MDB -> DEFAULT_HOST_INSTANCE == Base Database Connection Object. (MCore)
MDB -> GET_COLLECTION() == Uses DEFAULT_HOST_INSTANCE/MCore and initiates the collection object within.

Calling (MDB -> GET_COLLECTION()) will return you a fully fleshed out Database/Collection object that allows
you to easily work with that collection.

