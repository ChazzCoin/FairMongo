from fongUtils.fongLogger.CoreLogger import Log
from fongUtils.fongLogger import LogColors
from fongUtils.fongLogger import loggerUtils