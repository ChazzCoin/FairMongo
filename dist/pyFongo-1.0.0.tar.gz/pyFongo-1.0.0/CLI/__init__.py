from CLI.main import pyFongo

def start():
    pyFongo.RUN()