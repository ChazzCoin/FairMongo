

"""

-> PID
-> name
-> timeStarted
-> currentState
-> timeEnded
-> host
->
->

"""