from M.MCollection import MCollection
from M.MCore import MCore
from M.MQuery import Q, R, O, QBuilder
from M import MDB